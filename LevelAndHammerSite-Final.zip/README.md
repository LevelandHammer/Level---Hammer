# Level & Hammer Co. Website

This is a Vercel-ready Next.js project for Level & Hammer Co.

To deploy:
1. Upload this folder to a GitHub repo
2. Go to https://vercel.com and import the repo
3. Vercel will auto-deploy your site

To run locally:
```
npm install
npm run dev
```
